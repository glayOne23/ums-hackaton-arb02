# Review

- Alur mengikuti storyboard 10 adegan yang sudah disetujui; data di layar = screenshot asli dari Panduan Penggunaan SIGAP (data contoh).
- Narasi: suara offline Piper id_ID (sherpa-onnx). HeyGen/Kokoro tidak bisa dijangkau dari sesi ini.
- Tanpa musik latar: tidak ada sumber musik yang bisa dijangkau. Efek suara bawaan HyperFrames (pop, whoosh, riser, impact).
- Diukur: check (lint/layout/contrast/craft), snapshot --review, ffprobe. Suara diukur, tidak didengar.
- Peringatan yang dibiarkan: kontras saat elemen sedang fade-in (sesaat), kartu akhir ditahan dengan sengaja (data-hold).
- Paling lemah: kualitas suara TTS offline (agak datar), adegan 1 (ilustrasi CSS, bukan foto nyata).
