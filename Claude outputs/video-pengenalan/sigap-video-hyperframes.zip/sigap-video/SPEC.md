GOAL:    Penonton paham apa itu SIGAP, siapa memakainya, dan alur kerjanya dari awal sampai akhir.
OUTPUT:  HyperFrames, 1920 x 1080, 30 fps
TIME:    181.8 s x 30 = 5455 frame; narasi = jam (tanpa musik: tidak ada sumber musik di sesi ini)
LOOK:    ground #e8edf3 (latar aplikasi), ink #1c1917, aksen #166534 (bidang bab & kartu akhir),
         highlight #4f46e5 (sesuai token "data highlight" aplikasi); Inter 900 150px judul bab, 40px caption;
         medium: screenshot ASLI aplikasi di bingkai laptop (1240px) & HP (400px), bayangan 0 30 60 18%
OBJECTS: nota kertas bercap, lembar spreadsheet, laptop, HP, logo SIGAP dari favicon aplikasi
MOTION:  datang expo.out 0.35-0.8 s, kamera power2.inOut 0.9 s, ganti layar blur-swap 0.18/0.22 s,
         kartu bab dihapus clip-path ke atas 0.6 s power3.inOut
SHOTS:   s1 cara lama → s2 SIGAP → s3 4 peran → s4 Admin Kantor → s5 Admin Gudang → s6 Sales →
         s7 setoran/tagihan/opname → s8 Pimpinan → s9 koreksi → s10 kartu akhir
BANNED:  void gelap, glow, tiga kartu sejajar, logo di pojok, slide bullet, angka karangan
QA:      0 s (thumbnail tidak kosong), 25 s (brand tidak menabrak hero), 100 s (laku 2 · Rp90.000), 175 s (kartu akhir)
