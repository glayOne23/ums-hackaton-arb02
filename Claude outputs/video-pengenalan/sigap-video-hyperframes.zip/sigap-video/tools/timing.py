import json,subprocess,wave,numpy as np
VO='vo/'; D=json.load(open(VO+'durs.json')); S=json.load(open(VO+'script.json'))
say={sid:[(p[1] or p[0]) for p in ph] for sid,ph in S}
LEAD=0.9; GAP=0.7; TAIL=1.1; LAST_TAIL=3.6
scenes=[];t=0.0;sr=22050;buf=[]
order=[s for s,_ in S]
for k,sid in enumerate(order):
    ph=D[sid]; st=t; loc=LEAD; P=[]
    for i,p in enumerate(ph):
        P.append({'start':round(loc,3),'end':round(loc+p['dur'],3),'text':p['text'],'say':say[sid][i],'file':p['file']})
        loc+=p['dur']+(GAP if i<len(ph)-1 else 0)
    loc+= LAST_TAIL if k==len(order)-1 else TAIL
    scenes.append({'id':sid,'start':round(st,3),'dur':round(loc,3),'phrases':P}); t+=loc
total=round(t,3)
# assemble wav
out=np.zeros(int(total*sr)+sr,dtype=np.int16)
for sc in scenes:
    for p in sc['phrases']:
        w=wave.open(VO+p['file']);x=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2');i=int((sc['start']+p['start'])*sr);out[i:i+len(x)]=x
w=wave.open('vo/vo_full.wav','wb');w.setnchannels(1);w.setsampwidth(2);w.setframerate(sr);w.writeframes(out[:int(total*sr)].tobytes());w.close()
json.dump({'total':total,'scenes':scenes},open('timeline.json','w'),indent=1)
for s in scenes: print(s['id'],s['start'],s['dur'])
print('TOTAL',total)
