import json, re, html

TL = json.load(open('timeline.json'))
SC = {s['id']: s for s in TL['scenes']}
TOTAL = TL['total']
OUT = 'sigap-video/'

# ---------- geometry ----------
LAP = dict(left=340, top=58, w=1240, bez=18)          # laptop body
LAP_SW, LAP_SH = 1204, 752                            # screen box
LK = LAP_SW / 1920                                    # screenshot px -> screen px
PH = dict(left=520, top=96, w=400, bez=14)
PH_SW, PH_SH = 372, 805
PK = PH_SW / 780

CSS = """
<style>
#root{position:absolute;inset:0;font-family:Inter,sans-serif;color:#1c1917;overflow:hidden}
.ground{position:absolute;inset:0;background:#e8edf3}
.dev{position:absolute}
.lap{position:absolute;left:340px;top:58px;width:1240px;height:788px;background:#1c1917;border-radius:26px;box-shadow:0 30px 60px rgba(20,40,24,.20),0 4px 12px rgba(20,40,24,.12)}
.lapbase{position:absolute;left:250px;top:846px;width:1420px;height:24px;background:#a8a29e;border-radius:0 0 22px 22px;box-shadow:0 10px 20px rgba(20,40,24,.15)}
.lapnotch{position:absolute;left:880px;top:846px;width:160px;height:8px;background:#78716c;border-radius:0 0 8px 8px}
.lapscr{position:absolute;left:18px;top:18px;width:1204px;height:752px;overflow:hidden;border-radius:6px;background:#e8edf3}
.phone{position:absolute;width:400px;height:833px;background:#1c1917;border-radius:58px;box-shadow:0 30px 60px rgba(20,40,24,.22),0 4px 12px rgba(20,40,24,.12)}
.phscr{position:absolute;left:14px;top:14px;width:372px;height:805px;overflow:hidden;border-radius:46px;background:#e8edf3}
.scrn{position:absolute;inset:0;opacity:0}
.cam{position:absolute;left:0;top:0;transform-origin:0 0}
.cam img{position:absolute;left:0;top:0;display:block}
.hl{position:absolute;border:4px solid #4f46e5;border-radius:12px;opacity:0;box-shadow:0 0 0 6px rgba(79,70,229,.14)}
.chap{position:absolute;inset:0;background:#166534;color:#fff;display:flex;flex-direction:column;justify-content:center;padding-left:180px}
.chap h2{font-size:150px;font-weight:900;letter-spacing:-0.035em;line-height:1}
.chap h2 span{display:inline-block;opacity:0}
.chap p{font-size:46px;font-weight:400;color:#dcfce7;margin-top:28px;opacity:0}
.call{position:absolute;opacity:0;display:flex;align-items:center}
.call .ln{width:90px;height:4px;background:#4f46e5}
.call .dot{width:14px;height:14px;border-radius:7px;background:#4f46e5;margin-right:-4px}
.call .box{background:#1c1917;color:#fff;font-size:34px;font-weight:700;line-height:1.25;padding:20px 28px;border-radius:12px;max-width:760px}
.call .box small{display:block;font-size:28px;font-weight:400;color:#d6d3d1;margin-top:6px}
</style>"""

def esc(s): return html.escape(s, quote=True)

class Scene:
    def __init__(self, sid):
        self.sid = sid; self.s = SC[sid]; self.html = []; self.js = []; self.n = 0
        self.P = [p['start'] for p in self.s['phrases']]
        self.E = [p['end'] for p in self.s['phrases']]
        self.dur = self.s['dur']; self.sfx = []   # (abs time, file, vol)
    def id(self, name): return f"{self.sid}-{name}"
    def add(self, h): self.html.append(h)
    def t(self, js): self.js.append(js)
    def word_t(self, i, word):
        say = self.s['phrases'][i]['say'].lower(); k = say.find(word.lower())
        return self.P[i] + (self.E[i] - self.P[i]) * max(k, 0) / len(say)
    def sfx_at(self, t, f, vol=0.3): self.sfx.append((round(self.s['start'] + t, 3), f, vol))

    # ---- devices ----
    def laptop(self, screens, dev_in=0.0, from_y=70):
        dv = self.id('lap'); body = [f'<div id="{dv}" class="dev" style="left:0;top:0;width:1920px;height:1080px">',
                                     '<div class="lapbase"></div><div class="lapnotch"></div><div class="lap"><div class="lapscr">']
        for sc in screens: body.append(self._screen(sc, 'lap'))
        body.append('</div></div></div>'); self.add(''.join(body))
        if dev_in is not None:
            self.t(f'tl.fromTo("#{dv}",{{y:{from_y},opacity:0}},{{y:0,opacity:1,duration:0.8,ease:"expo.out"}},{dev_in:.3f});')
        self._screen_js(screens, 'lap')
        return dv
    def phone(self, screens, left=520, top=96, dev_in=0.0, dev_id='ph'):
        dv = self.id(dev_id)
        body = [f'<div id="{dv}" class="phone" style="left:{left}px;top:{top}px"><div class="phscr">']
        for sc in screens: body.append(self._screen(sc, 'ph'))
        body.append('</div></div>'); self.add(''.join(body))
        if dev_in is not None:
            self.t(f'tl.fromTo("#{dv}",{{y:80,opacity:0}},{{y:0,opacity:1,duration:0.8,ease:"expo.out"}},{dev_in:.3f});')
        self._screen_js(screens, 'ph')
        return dv
    def _screen(self, sc, kind):
        k = LK if kind == 'lap' else PK
        sw = 1920 if kind == 'lap' else 780; sh = 1200 if kind == 'lap' else 1688
        sc['_id'] = self.id(f"sc{self.n}"); self.n += 1
        h = [f'<div id="{sc["_id"]}" class="scrn"><div id="{sc["_id"]}-cam" class="cam">',
             f'<img src="assets/shots/{sc["img"]}.jpg" style="width:{sw*k:.1f}px;height:{sh*k:.1f}px" alt="">']
        for j, hl in enumerate(sc.get('hls', [])):
            x0, y0, x1, y1 = hl['box']; pad = 8
            h.append(f'<div id="{sc["_id"]}-hl{j}" class="hl" style="left:{x0*k-pad:.1f}px;top:{y0*k-pad:.1f}px;width:{(x1-x0)*k+2*pad:.1f}px;height:{(y1-y0)*k+2*pad:.1f}px"></div>')
        h.append('</div></div>'); return ''.join(h)
    def _screen_js(self, screens, kind):
        k = LK if kind == 'lap' else PK
        W, H = (LAP_SW, LAP_SH) if kind == 'lap' else (PH_SW, PH_SH)
        imgH = (1200 if kind == 'lap' else 1688) * k
        for i, sc in enumerate(screens):
            sid = sc['_id']; t0 = sc['at']
            if i == 0:
                self.t(f'tl.set("#{sid}",{{opacity:1}},0);')
            else:
                prev = screens[i-1]['_id']
                self.t(f'tl.to("#{prev}",{{opacity:0,filter:"blur(8px)",duration:0.18,ease:"power2.in"}},{t0:.3f});')
                self.t(f'tl.fromTo("#{sid}",{{opacity:0,filter:"blur(8px)"}},{{opacity:1,filter:"blur(0px)",duration:0.22,ease:"power2.out"}},{t0+0.08:.3f});')
            self.t(f'tl.set("#{sid}-cam",{{scale:1,x:0,y:0}},0);')
            for c in sc.get('cams', []):
                t, z, cx, cy = c[:4]; d = c[4] if len(c) > 4 else 0.9
                tx = W/2 - z*cx*k; ty = H/2 - z*cy*k
                tx = min(0, max(W - z*W, tx)); ty = min(0, max(H - z*imgH, ty))
                self.t(f'tl.to("#{sid}-cam",{{scale:{z},x:{tx:.1f},y:{ty:.1f},duration:{d},ease:"power2.inOut"}},{t:.3f});')
            for j, hl in enumerate(sc.get('hls', [])):
                on, off = hl['on'], hl['off']
                self.t(f'tl.fromTo("#{sid}-hl{j}",{{opacity:0,scale:1.08}},{{opacity:1,scale:1,duration:0.35,ease:"expo.out"}},{on:.3f});')
                self.t(f'tl.to("#{sid}-hl{j}",{{opacity:0,duration:0.2,ease:"power2.in"}},{off:.3f});')
                if hl.get('sfx', True): self.sfx_at(on + 0.03, 'pop' if j % 2 == 0 else 'click-soft', 0.22)
    def chapter(self, name, duty, out_t):
        c = self.id('chap'); letters = ''.join(f'<span>{esc(ch) if ch != " " else "&nbsp;"}</span>' for ch in name)
        self.add(f'<div id="{c}" class="chap"><h2 id="{c}-h">{letters}</h2><p id="{c}-p">{esc(duty)}</p></div>')
        self.t(f'tl.fromTo("#{c}-h span",{{opacity:0.25,filter:"blur(6px)"}},{{opacity:1,filter:"blur(0px)",duration:0.25,stagger:0.05,ease:"power3.out"}},0.15);')
        self.t(f'tl.fromTo("#{c}-p",{{opacity:0,filter:"blur(8px)"}},{{opacity:1,filter:"blur(0px)",duration:0.2,ease:"power3.out"}},0.75);')
        self.t(f'tl.fromTo("#{c}",{{clipPath:"inset(0% 0% 0% 0%)"}},{{clipPath:"inset(0% 0% 100% 0%)",duration:0.6,ease:"power3.inOut"}},{out_t:.3f});')
        self.sfx_at(out_t + 0.05, 'whoosh', 0.3)
    def callout(self, on, off, x, y, text, sub=None, side='right'):
        c = self.id(f"call{self.n}"); self.n += 1
        sm = f'<small>{esc(sub)}</small>' if sub else ''
        self.add(f'<div id="{c}" class="call" style="left:{x}px;top:{y}px"><div class="dot"></div><div class="ln"></div><div class="box">{esc(text)}{sm}</div></div>')
        self.t(f'tl.fromTo("#{c}",{{opacity:0,x:-24,filter:"blur(6px)"}},{{opacity:1,x:0,filter:"blur(0px)",duration:0.4,ease:"expo.out"}},{on:.3f});')
        self.t(f'tl.to("#{c}",{{opacity:0,filter:"blur(6px)",duration:0.2,ease:"power2.in"}},{off:.3f});')
    def write(self, extra_css=''):
        body = ''.join(self.html)
        js = '\n'.join(self.js)
        doc = f"""<template>
{CSS}
<style>{extra_css}</style>
<div id="root" data-composition-id="{self.sid}" data-width="1920" data-height="1080">
<div class="ground"></div>
{body}
</div>
<script>
const tl = gsap.timeline({{ paused: true }});
{js}
tl.set({{}},{{}},{self.dur:.3f});
window.__timelines["{self.sid}"] = tl;
</script>
</template>
"""
        open(f'{OUT}compositions/{self.sid}.html', 'w').write(doc)

scenes = []

# ---------------- S1: the old way ----------------
s = Scene('s1'); P, E = s.P, s.E
notes = []
rows = [("Madu Hutan 250", "5", "3", "2"), ("Madu Pahit 470", "5", "5", "0"), ("Sari Kurma 330", "5", "4", "1"), ("Habbatussauda", "4", "4", "0")]
for i, (rot, dx, dy) in enumerate([(-7, 0, 30), (4, 40, 0), (-2, 80, 50)]):
    r = ''.join(f'<div class="nrow"><span>{a}</span><b>{b}</b><b>{c}</b><b>{d}</b></div>' for a, b, c, d in rows)
    notes.append(f'<div id="s1-n{i}" class="nota" data-layout-allow-overlap style="left:{150+dx}px;top:{150+dy}px"><div class="nh">NOTA TITIP</div><div class="ns">Apotek ... · tgl ..</div><div class="nrow nhd"><span>Produk</span><b>Ttp</b><b>Sisa</b><b>Laku</b></div>{r}<div class="nsig">cap &amp; ttd</div></div>')
s.add(f'<div id="s1-notes">{"".join(notes)}</div>')
cells = []
vals = [["Outlet", "Produk", "Ttp", "Sisa", "Laku"]] + [[f"Apotek {n}", p, "5", str(3+i % 3), str(2-i % 3 if 2-i % 3 > 0 else 0)] for i, (n, p) in enumerate([("Sari", "Madu Hutan"), ("Sehat", "Madu Pahit"), ("Jaya", "Sari Kurma"), ("Barokah", "Madu Hutan"), ("Sentosa", "Cuka Apel"), ("Waras", "Madu Pahit"), ("Mulya", "Sari Kurma")])]
for r, row in enumerate(vals):
    for c, v in enumerate(row):
        cells.append(f'<div id="s1-c{r}-{c}" class="cell{" hd" if r == 0 else ""}">{esc(v)}</div>')
s.add(f'<div id="s1-sheet" data-layout-allow-overlap><div class="tabs"><span>OKT-ENDRI.xlsx</span><span>OKT-MONIC.xlsx</span><span>REKAP.xlsx</span></div><div class="grid">{"".join(cells)}</div></div>')
s.add('<svg id="s1-arrow" width="220" height="80" viewBox="0 0 220 80" style="position:absolute;left:745px;top:430px"><path id="s1-arr" d="M10 40 C 70 10, 140 10, 200 40" fill="none" stroke="#57534e" stroke-width="6" stroke-linecap="round" pathLength="100" stroke-dasharray="100 120" stroke-dashoffset="110"/><path id="s1-arh" d="M184 26 L204 41 L182 52" fill="none" stroke="#57534e" stroke-width="6" stroke-linecap="round" stroke-linejoin="round" opacity="0"/></svg>')
words = [("Lambat.", 'lambat'), ("Mudah salah.", 'mudah'), ("Sulit dipantau.", 'sulit')]
s.add('<div id="s1-big" data-layout-allow-overlap data-layout-allow-occlusion>' + ''.join(f'<div id="s1-w{i}" class="bigw">{esc(w)}</div>' for i, (w, _) in enumerate(words)) + '</div>')
for i in range(3):
    st = 0.0 if i == 0 else P[0]+0.4+i*0.35
    s.t(f'tl.fromTo("#s1-n{i}",{{opacity:{1 if i == 0 else 0},y:{-30 if i == 0 else -120},rotation:{[-10,10,-8][i]}}},{{opacity:1,y:0,rotation:{[-7,4,-2][i]},duration:0.7,ease:"expo.out"}},{st:.3f});')
s.t(f'tl.to("#s1-arr",{{strokeDashoffset:0,duration:0.6,ease:"power2.inOut"}},{P[1]+0.2:.3f});')
s.t(f'tl.to("#s1-arh",{{opacity:1,duration:0.15}},{P[1]+0.75:.3f});')
s.t(f'tl.fromTo("#s1-sheet",{{opacity:0,x:60}},{{opacity:1,x:0,duration:0.6,ease:"expo.out"}},{P[1]+0.5:.3f});')
nc = len(vals) * 5
s.t(f'tl.fromTo("#s1-sheet .cell",{{opacity:0}},{{opacity:1,duration:0.05,stagger:{(E[1]-P[1]-1.0)/nc:.4f}}},{P[1]+1.0:.3f});')
s.t(f'tl.to(["#s1-notes","#s1-sheet","#s1-arrow"],{{opacity:0.22,filter:"blur(5px)",duration:0.5,ease:"power2.inOut"}},{P[2]-0.1:.3f});')
for i, (w, key) in enumerate(words):
    t = s.word_t(2, key)
    s.t(f'tl.fromTo("#s1-w{i}",{{opacity:0,filter:"blur(10px)"}},{{opacity:1,filter:"blur(0px)",duration:0.18,ease:"power4.out"}},{t:.3f});')
    s.sfx_at(t + 0.03, 'click-soft', 0.25)
s.write("""
#root .ground{background:#fafaf9}
.nota{position:absolute;width:470px;height:560px;background:#fff;border-radius:6px;padding:34px 36px;box-shadow:0 12px 28px rgba(28,25,23,.16);opacity:0}
.nh{font-size:34px;font-weight:900;letter-spacing:.06em}.ns{font-size:28px;color:#78716c;margin:6px 0 24px}
.nrow{display:flex;font-size:28px;color:#1e3a8a;padding:12px 0;border-bottom:2px dashed #d6d3d1}.nrow span{flex:1}.nrow b{width:64px;text-align:right;font-weight:700}
.nhd{color:#57534e;font-size:28px;font-weight:700}.nsig{margin-top:30px;font-size:28px;color:#b45309;transform:rotate(-6deg);border:3px solid #b45309;width:180px;text-align:center;border-radius:10px;padding:6px}
#s1-sheet{position:absolute;left:980px;top:200px;width:800px;background:#fff;box-shadow:0 12px 28px rgba(28,25,23,.16);border-radius:8px;overflow:hidden;opacity:0}
#s1-sheet .tabs{display:flex;gap:6px;background:#e7e5e4;padding:10px 10px 0}#s1-sheet .tabs span{background:#fff;font-size:28px;padding:8px 14px;border-radius:6px 6px 0 0;color:#57534e}
#s1-sheet .grid{display:grid;grid-template-columns:200px 210px 110px 140px 140px}
.cell{font-size:28px;padding:10px 14px;border-right:1px solid #e7e5e4;border-bottom:1px solid #e7e5e4;height:52px;white-space:nowrap}.cell.hd{background:#166534;color:#fff;font-weight:700}
#s1-big{position:absolute;left:180px;top:250px}
.bigw{font-size:150px;font-weight:900;letter-spacing:-0.04em;line-height:1.08;color:#1c1917;opacity:0}
#s1-w2{color:#b91c1c}
""")
scenes.append(s)

# ---------------- S2: SIGAP reveal ----------------
s = Scene('s2'); P, E = s.P, s.E
logo = open(OUT + 'assets/logo.svg').read().replace('<svg ', '<svg id="s2-mark" ')
s.add(f'<div id="s2-field"></div><div id="s2-brand"><div id="s2-markw">{logo}</div><div id="s2-word">' + ''.join(f'<span>{c}</span>' for c in "SIGAP") + '</div><div id="s2-sub">CV Arba\'in Jaya Mandiri</div></div>')
s.add('<div id="s2-hero"><img src="assets/shots/00.jpg" alt=""></div>')
s.add('<div id="s2-off"><svg width="54" height="54" viewBox="0 0 24 24" fill="none" stroke="#166534" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m2 2 20 20"/><path d="M5.782 5.782A7 7 0 0 0 9 19h8.5a4.5 4.5 0 0 0 1.307-.193"/><path d="M21.532 16.5A4.5 4.5 0 0 0 17.5 10h-1.79A7.008 7.008 0 0 0 10 5.07"/></svg><div>Tanpa sinyal tetap jalan<small>tersimpan di HP, terkirim saat ada sinyal</small></div></div>')
s.t('tl.fromTo("#s2-field",{clipPath:"circle(0% at 50% 50%)"},{clipPath:"circle(75% at 50% 50%)",duration:0.5,ease:"power2.inOut"},0);')
s.sfx_at(0.05, 'whoosh-short', 0.3)
s.t(f'tl.fromTo("#s2-markw",{{opacity:0,scale:0.6,filter:"blur(10px)"}},{{opacity:1,scale:1,filter:"blur(0px)",duration:0.6,ease:"expo.out"}},{P[0]+0.6:.3f});')
s.t(f'tl.fromTo("#s2-word span",{{opacity:0,filter:"blur(6px)"}},{{opacity:1,filter:"blur(0px)",duration:0.2,stagger:0.08,ease:"power3.out"}},{P[0]+0.9:.3f});')
s.t(f'tl.fromTo("#s2-sub",{{opacity:0}},{{opacity:1,duration:0.3}},{P[0]+1.4:.3f});')
s.sfx_at(P[0] + 0.62, 'impact-bass-1', 0.3)
s.t(f'tl.to("#s2-sub",{{opacity:0,duration:0.2}},{P[1]-0.25:.3f});')
s.t(f'tl.to("#s2-brand",{{x:-690,y:-420,scale:0.42,duration:0.8,ease:"power3.inOut"}},{P[1]-0.2:.3f});')
s.t(f'tl.fromTo("#s2-hero",{{opacity:0,y:140,scale:0.92}},{{opacity:1,y:0,scale:1,duration:0.9,ease:"expo.out"}},{P[1]+0.1:.3f});')
s.t(f'tl.to("#s2-hero img",{{scale:1.05,duration:{E[1]-P[1]+1.5:.2f},ease:"none"}},{P[1]+0.1:.3f});')
s.t(f'tl.fromTo("#s2-off",{{opacity:0,x:-30,filter:"blur(6px)"}},{{opacity:1,x:0,filter:"blur(0px)",duration:0.45,ease:"expo.out"}},{P[2]:.3f});')
s.sfx_at(P[2] + 0.03, 'pop', 0.25)
s.write("""
#root .ground{background:#e8edf3}
#s2-field{position:absolute;inset:0;background:#166534}
#s2-brand{position:absolute;left:0;top:0;width:1920px;height:1080px;display:flex;flex-direction:column;align-items:center;justify-content:center;transform-origin:50% 50%}
#s2-markw{width:200px;height:200px;opacity:0}#s2-markw svg{width:200px;height:200px}
#s2-word{font-size:190px;font-weight:900;color:#fff;letter-spacing:-0.03em;line-height:1;margin-top:26px}#s2-word span{display:inline-block}
#s2-sub{font-size:44px;color:#dcfce7;margin-top:18px;opacity:0}
#s2-hero{position:absolute;left:360px;top:250px;width:1200px;height:700px;border-radius:24px;overflow:hidden;background:#fff;box-shadow:0 30px 60px rgba(0,0,0,.25);opacity:0}
#s2-hero img{width:1200px;height:700px;display:block;transform-origin:50% 60%}
#s2-off{position:absolute;left:1150px;top:120px;display:flex;align-items:center;gap:18px;background:#fff;border-radius:14px;padding:20px 28px;box-shadow:0 12px 28px rgba(0,0,0,.2);opacity:0}
#s2-off div{font-size:36px;font-weight:700;color:#14532d}#s2-off small{display:block;font-size:28px;font-weight:400;color:#57534e;margin-top:4px}
""")
scenes.append(s)

# ---------------- S3: roles ----------------
s = Scene('s3'); P, E = s.P, s.E
tP = s.word_t(0, 'pimpinan'); tK = s.word_t(0, 'admin kantor'); tG = s.word_t(0, 'admin gudang'); tS = s.word_t(0, 'dan sales')
scr = [
    dict(img='45', at=0, cams=[(P[0]-0.2, 1.38, 1150, 830, 1.0)],
         hls=[dict(box=(437, 792, 1870, 900), on=tP, off=tK - 0.05),
              dict(box=(437, 653, 1870, 783), on=tK, off=tG - 0.05),
              dict(box=(437, 550, 1870, 650), on=tG, off=tS - 0.05),
              dict(box=(437, 900, 1870, 1108), on=tS, off=E[0] + 0.4)]),
    dict(img='46', at=P[1] + 0.2, cams=[(P[1] + 0.4, 1.12, 1100, 600, 2.5)]),
]
s.laptop(scr, dev_in=0.1)
s.write()
scenes.append(s)

# ---------------- S4: Admin Kantor ----------------
s = Scene('s4'); P, E = s.P, s.E
out = E[0] + 0.15
scr = [
    dict(img='48', at=0, cams=[(out + 0.4, 1.0, 960, 600)], hls=[dict(box=(437, 308, 1870, 492), on=P[1] + 1.2, off=E[1] + 0.3)]),
    dict(img='29', at=P[2] - 0.1, cams=[(P[2], 1.15, 1100, 520, 2.0)]),
    dict(img='42', at=s.word_t(2, 'produk'), hls=[dict(box=(437, 815, 1870, 953), on=s.word_t(2, 'potongan'), off=E[2] + 0.4)]),
    dict(img='47', at=P[3] - 0.1, cams=[(P[3] + 0.3, 1.7, 800, 560, 1.0)], hls=[dict(box=(437, 400, 1167, 723), on=s.word_t(3, 'batas'), off=E[3] + 0.5)]),
]
s.laptop(scr, dev_in=None)
s.chapter('Admin Kantor', 'Menyiapkan data dan aturan kerja', out)
s.write()
scenes.append(s)

# ---------------- S5: Admin Gudang ----------------
s = Scene('s5'); P, E = s.P, s.E
out = s.word_t(0, 'mencatat') + 0.2
scr = [
    dict(img='50', at=0, cams=[(out + 0.5, 1.45, 1300, 480, 1.0)], hls=[dict(box=(1050, 492, 1833, 592), on=s.word_t(0, 'nomor bets'), off=E[0] + 0.4)]),
    dict(img='53', at=P[1] - 0.05, cams=[(P[1] + 0.1, 1.2, 1150, 800, 1.0), (P[2] - 0.1, 1.5, 900, 640, 0.9)],
         hls=[dict(box=(437, 507, 1870, 1190), on=s.word_t(1, 'gudang'), off=P[2] - 0.1),
              dict(box=(517, 182, 1167, 222), on=P[2] + 0.5, off=E[2] + 0.6),
              dict(box=(458, 1040, 1225, 1157), on=E[2] - 0.6, off=E[2] + 0.8)]),
]
s.laptop(scr, dev_in=None)
s.chapter('Admin Gudang', 'Barang masuk dan permintaan sales', out)
s.write()
scenes.append(s)

# ---------------- S6: Sales ----------------
s = Scene('s6'); P, E = s.P, s.E
out = s.word_t(0, 'sales membuka') + 0.1
CX = 520 + 14; CY = 96 + 14   # phone screen origin on canvas
def py(y): return CY + y * PK
scr = [
    dict(img='15', at=0, cams=[(s.word_t(0, 'yang paling'), 1.18, 390, 1178, E[0]-s.word_t(0, 'yang paling'))], hls=[dict(box=(36, 956, 744, 1400), on=s.word_t(0, 'yang paling'), off=E[0] + 0.3)]),
    dict(img='17', at=P[1] - 0.1, hls=[dict(box=(352, 650, 716, 744), on=s.word_t(1, 'sales cukup'), off=E[1] + 0.2)]),
    dict(img='18', at=P[2] - 0.05, cams=[(P[2] + 0.2, 1.25, 390, 730, E[2]-P[2])], hls=[dict(box=(30, 640, 750, 820), on=P[2] + 0.4, off=E[2] + 0.3)]),
    dict(img='17b', at=P[3] - 0.05, hls=[dict(box=(32, 330, 746, 436), on=P[3] + 0.4, off=E[3] + 0.3)]),
    dict(img='19', at=P[4] - 0.45, hls=[dict(box=(30, 1416, 750, 1526), on=P[4] - 0.3, off=s.word_t(4, 'nota') + 0.35)]),
    dict(img='20', at=s.word_t(4, 'nota') + 0.4, hls=[dict(box=(30, 220, 746, 350), on=s.word_t(4, 'nota') + 0.6, off=E[5] + 0.5)]),
]
s.phone(scr, dev_in=None)
X = 520 + 400 + 10
s.callout(s.word_t(0, 'yang paling'), E[0] + 0.3, X, py(1178) - 60, 'Paling lama tidak dikunjungi', 'tampil paling atas')
s.callout(s.word_t(1, 'sales cukup'), E[1] + 0.2, X, py(697) - 60, 'Sisa sudah terisi', 'cukup ubah yang berkurang')
s.callout(P[2] + 0.5, E[2] + 0.3, X, py(730) - 60, 'Laku 2 · Rp90.000', 'dihitung otomatis')
s.callout(P[3] + 0.4, E[3] + 0.3, X, py(383) - 40, 'Tidak ada yang laku', 'satu tombol, selesai')
s.callout(P[4] - 0.3, s.word_t(4, 'nota') + 0.35, X, py(1471) - 60, 'Catat pembayaran', 'tunai atau transfer')
s.callout(s.word_t(4, 'nota') + 0.6, P[5] - 0.1, X, py(285) - 60, 'Nota ke WhatsApp outlet', 'tersimpan dan terkirim')
mid5 = s.word_t(5, 'dan terkirim')
s.callout(P[5] + 0.2, mid5 - 0.1, X, py(285) - 60, 'Tanpa sinyal', 'tetap tersimpan di HP')
s.callout(mid5 + 0.1, E[5] + 0.5, X, py(285) - 60, 'Sinyal kembali', 'terkirim sendiri ke kantor')
s.chapter('Sales', 'Kunjungan di lapangan', out)
s.write()
scenes.append(s)

# ---------------- S7: setoran, tagihan, gudang ----------------
s = Scene('s7'); P, E = s.P, s.E
scr = [
    dict(img='38', at=0, cams=[(P[0] - 0.3, 1.35, 1150, 560, 1.0)], hls=[dict(box=(437, 532, 1870, 637), on=s.word_t(0, 'admin kantor'), off=E[0] + 0.3)]),
    dict(img='36', at=P[1] - 0.1, cams=[(P[1] + 0.1, 1.3, 1150, 700, 1.0), (s.word_t(1, 'bisa dicetak') - 0.3, 1.6, 1400, 560, 0.9)],
         hls=[dict(box=(433, 617, 1870, 847), on=P[1] + 0.5, off=s.word_t(1, 'bisa dicetak') - 0.35), dict(box=(1305, 500, 1847, 558), on=s.word_t(1, 'bisa dicetak') + 0.3, off=E[1] + 0.3)]),
    dict(img='55', at=P[2] - 0.1, cams=[(P[2] + 0.1, 1.2, 1100, 600, 1.8)], hls=[dict(box=(517, 185, 1383, 222), on=P[2] + 0.8, off=E[2] + 0.6)]),
]
s.laptop(scr, dev_in=0.1)
s.write()
scenes.append(s)

# ---------------- S8: Pimpinan ----------------
s = Scene('s8'); P, E = s.P, s.E
out = s.word_t(0, 'melihat') + 0.1
scr = [
    dict(img='57', at=0, cams=[(out + 0.4, 1.0, 960, 600)],
         hls=[dict(box=(433, 387, 772, 600), on=s.word_t(0, 'omzet'), off=s.word_t(0, 'performa') - 0.05),
              dict(box=(433, 633, 1138, 1158), on=s.word_t(0, 'performa'), off=s.word_t(0, 'outlet paling') - 0.05),
              dict(box=(1163, 633, 1870, 1158), on=s.word_t(0, 'outlet paling'), off=E[0] + 0.3)]),
    dict(img='58', at=P[1] - 0.1, cams=[(P[1] + 0.1, 1.15, 1150, 700, 1.0)],
         hls=[dict(box=(433, 382, 1138, 1190), on=P[1] + 0.4, off=s.word_t(1, 'perlu tindakan') - 0.05),
              dict(box=(1163, 382, 1870, 957), on=s.word_t(1, 'perlu tindakan'), off=E[1] + 0.3)]),
    dict(img='60', at=P[2] - 0.1, cams=[(P[2] + 0.1, 1.45, 1350, 420, 1.0)], hls=[dict(box=(1513, 217, 1870, 275), on=s.word_t(2, 'ekssel'), off=E[2] + 0.6)]),
]
s.laptop(scr, dev_in=None)
s.chapter('Pimpinan', 'Memantau dan memutuskan', out)
s.write()
scenes.append(s)

# ---------------- S9: koreksi ----------------
s = Scene('s9'); P, E = s.P, s.E
s.phone([dict(img='20', at=0, cams=[(0.2, 1.0, 390, 844)], hls=[dict(box=(46, 382, 486, 452), on=P[0] + 0.5, off=E[0] + 0.4)])], left=760, top=96, dev_in=0.1, dev_id='ph')
s.t(f'tl.to("#s9-ph",{{x:-900,opacity:0,duration:0.5,ease:"power3.in"}},{P[1]-0.45:.3f});')
scr = [
    dict(img='35', at=0, cams=[(P[1], 1.6, 900, 420, 0.9)], hls=[dict(box=(433, 318, 913, 443), on=P[1] + 0.5, off=s.word_t(1, 'data yang bentrok') - 0.15)]),
    dict(img='62', at=s.word_t(1, 'data yang bentrok') - 0.1, cams=[(s.word_t(1, 'data yang bentrok'), 1.3, 1150, 480, 0.9)],
         hls=[dict(box=(433, 500, 1870, 730), on=s.word_t(1, 'data yang bentrok') + 0.3, off=P[2] - 0.05),
              dict(box=(995, 250, 1225, 313), on=s.word_t(2, 'terhapus'), off=E[2] + 0.6)]),
]
s.laptop(scr, dev_in=P[1] - 0.3, from_y=0)
s.write()
scenes.append(s)

# ---------------- S10: end card ----------------
s = Scene('s10'); P, E = s.P, s.E
logo = open(OUT + 'assets/logo.svg').read().replace('<svg ', '<svg id="s10-mark" ')
s.add(f'<div id="s10-field"></div><div id="s10-wrap" data-hold><div id="s10-markw">{logo}</div><div id="s10-word">' + ''.join(f'<span>{c}</span>' for c in "SIGAP") +
      '</div><div id="s10-tag"><span>Catat sekali,</span> <span>semua langsung tahu.</span></div><div id="s10-co">CV Arba\'in Jaya Mandiri</div><div id="s10-cr">Antech Async · UMS HI Hackathon 2026</div></div>')
s.t('tl.fromTo("#s10-field",{clipPath:"inset(100% 0% 0% 0%)"},{clipPath:"inset(0% 0% 0% 0%)",duration:0.6,ease:"power3.inOut"},0);')
s.sfx_at(0.0, 'riser', 0.25)
s.t(f'tl.fromTo("#s10-markw",{{opacity:0,scale:2.2,filter:"blur(14px)"}},{{opacity:1,scale:1,filter:"blur(0px)",duration:0.55,ease:"power3.out"}},{P[0]-0.35:.3f});')
s.sfx_at(P[0] + 0.2, 'impact-bass-1', 0.32)
s.t(f'tl.fromTo("#s10-word span",{{opacity:0,filter:"blur(6px)"}},{{opacity:1,filter:"blur(0px)",duration:0.2,stagger:0.07,ease:"power3.out"}},{P[0]+0.1:.3f});')
s.t(f'tl.fromTo("#s10-tag span",{{opacity:0,filter:"blur(8px)"}},{{opacity:1,filter:"blur(0px)",duration:0.2,stagger:0.5,ease:"power3.out"}},{s.word_t(0, "catat"):.3f});')
s.t(f'tl.fromTo("#s10-co",{{opacity:0}},{{opacity:1,duration:0.4}},{s.word_t(1, "distribusi"):.3f});')
s.t(f'tl.fromTo("#s10-cr",{{opacity:0}},{{opacity:1,duration:0.4}},{E[1]+0.3:.3f});')
s.write("""
#s10-field{position:absolute;inset:0;background:#166534}
#s10-wrap{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;color:#fff}
#s10-markw{width:170px;height:170px;opacity:0}#s10-markw svg{width:170px;height:170px}
#s10-word{font-size:170px;font-weight:900;letter-spacing:-0.03em;line-height:1;margin-top:20px}#s10-word span{display:inline-block}
#s10-tag{font-size:64px;font-weight:700;margin-top:34px}#s10-tag span{display:inline-block;opacity:0}#s10-tag span:last-child{color:#bbf7d0}
#s10-co{font-size:40px;color:#dcfce7;margin-top:40px;opacity:0}
#s10-cr{font-size:30px;color:#bbf7d0;margin-top:12px;opacity:0}
""")
scenes.append(s)

# ---------------- captions ----------------
groups = []
for sc in TL['scenes']:
    for p in sc['phrases']:
        words = p['text'].split(); a0 = sc['start'] + p['start']; a1 = sc['start'] + p['end']
        n = len(words); k = max(1, round(n / 7)); size = -(-n // k)
        chunks = [words[i:i+size] for i in range(0, n, size)]
        L = sum(len(' '.join(c)) for c in chunks); t = a0
        for c in chunks:
            txt = ' '.join(c); d = (a1 - a0) * len(txt) / L
            groups.append((round(t, 3), round(t + d, 3), txt)); t += d
cap_html = ''.join(f'<div id="cap{i}" class="cg"><span>{esc(t)}</span></div>' for i, (_, _, t) in enumerate(groups))
cap_js = []
for i, (a, b, _) in enumerate(groups):
    nxt = groups[i+1][0] if i + 1 < len(groups) else TOTAL
    endt = min(b + 0.15, nxt - 0.02)
    cap_js.append(f'tl.fromTo("#cap{i}",{{opacity:0,visibility:"visible"}},{{opacity:1,duration:0.1}},{max(a,0.15):.3f});')
    cap_js.append(f'tl.to("#cap{i}",{{opacity:0,duration:0.08,ease:"power2.in"}},{endt-0.09:.3f});')
    cap_js.append(f'tl.set("#cap{i}",{{opacity:0,visibility:"hidden"}},{endt:.3f});')
open(OUT + 'compositions/captions.html', 'w').write(f"""<template>
<style>
#root{{position:absolute;inset:0;font-family:Inter,sans-serif}}
.cg{{position:absolute;left:0;width:1920px;bottom:44px;text-align:center;opacity:0;visibility:hidden}}
.cg span{{display:inline-block;background:rgba(28,25,23,.78);color:#fff;font-size:40px;font-weight:700;line-height:1.3;padding:10px 26px;border-radius:10px;max-width:1500px}}
</style>
<div id="root" data-composition-id="captions" data-width="1920" data-height="1080">{cap_html}</div>
<script>
const tl = gsap.timeline({{ paused: true }});
{chr(10).join(cap_js)}
tl.set({{}},{{}},{TOTAL:.3f});
window.__timelines["captions"] = tl;
</script>
</template>
""")

# ---------------- root ----------------
hosts = []
for s in scenes:
    hosts.append(f'<div id="{s.sid}" data-composition-id="{s.sid}" data-composition-src="compositions/{s.sid}.html" data-start="{s.s["start"]}" data-duration="{s.dur}" data-track-index="0" data-track-kind="graphics" data-width="1920" data-height="1080"></div>')
hosts.append(f'<div id="captions" data-composition-id="captions" data-composition-src="compositions/captions.html" data-start="0" data-duration="{TOTAL}" data-track-index="1" data-track-kind="captions" data-width="1920" data-height="1080" style="z-index:50"></div>')
aud = [f'<audio id="vo" class="clip" src="assets/voiceover.mp3" data-start="0" data-duration="{TOTAL}" data-track-index="3" data-volume="1"></audio>']
import subprocess
DUR = {}
sfx = sorted(x for s in scenes for x in s.sfx)
lanes_end = []
for i, (t, f, v) in enumerate(sfx):
    if f not in DUR:
        DUR[f] = float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',OUT+f'assets/sfx/{f}.mp3']).decode())
    d = min(DUR[f], TOTAL - t - 0.01)
    lane = next((j for j, e in enumerate(lanes_end) if e <= t), None)
    if lane is None: lanes_end.append(0); lane = len(lanes_end) - 1
    lanes_end[lane] = t + d
    aud.append(f'<audio id="sfx{i}" class="clip" src="assets/sfx/{f}.mp3" data-start="{t}" data-duration="{d:.3f}" data-track-index="{4+lane}" data-volume="{v}"></audio>')
open(OUT + 'index.html', 'w').write(f"""<!doctype html>
<html lang="id">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=1920, height=1080" />
<script src="assets/gsap.min.js"></script>
<style>
*{{margin:0;padding:0;box-sizing:border-box}}
html,body{{margin:0;width:1920px;height:1080px;overflow:hidden;background:#e8edf3}}
#root{{position:relative;width:1920px;height:1080px;font-family:Inter,sans-serif}}
</style>
</head>
<body>
<div id="root" data-composition-id="main" data-start="0" data-duration="{TOTAL}" data-width="1920" data-height="1080">
{chr(10).join(hosts)}
{chr(10).join(aud)}
</div>
<script>
window.__timelines = window.__timelines || {{}};
window.__timelines["main"] = gsap.timeline({{ paused: true }});
</script>
</body>
</html>
""")
print('scenes', len(scenes), 'captions', len(groups), 'sfx', len(sfx), 'total', TOTAL)
