import json,sys,subprocess,wave,sherpa_onnx,numpy as np
D='/tmp/claude-0/-home-claude/b3287852-d465-5cfa-a51f-9878306c637e/scratchpad/tts/vits-piper-id_ID-news_tts-medium/'
tts=sherpa_onnx.OfflineTts(sherpa_onnx.OfflineTtsConfig(model=sherpa_onnx.OfflineTtsModelConfig(vits=sherpa_onnx.OfflineTtsVitsModelConfig(model=D+'id_ID-news_tts-medium.onnx',tokens=D+'tokens.txt',data_dir=D+'espeak-ng-data',length_scale=1.05),num_threads=4)))
S=json.load(open('script.json')); out={}
for sid,ph in S:
    out[sid]=[]
    for i,(disp,say) in enumerate(ph):
        a=tts.generate(say or disp,sid=0,speed=1.0)
        x=(np.clip(np.array(a.samples),-1,1)*32767).astype('<i2')
        fn=f'{sid}_{i}.wav'; w=wave.open(fn,'wb');w.setnchannels(1);w.setsampwidth(2);w.setframerate(a.sample_rate);w.writeframes(x.tobytes());w.close()
        out[sid].append({'text':disp,'file':fn,'dur':round(len(x)/a.sample_rate,3)})
json.dump(out,open('durs.json','w'),indent=1)
tot=0
for s,v in out.items():
    d=sum(p['dur'] for p in v); tot+=d; print(s,round(d,1),[p['dur'] for p in v])
print('total speech',round(tot,1))
